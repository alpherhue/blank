from flask import Flask, render_template, send_from_directory, send_file
import os

# Create Flask app
app = Flask(__name__)

@app.route('/')
def home():
    # Read the HTML file content
    with open('index.html', 'r') as file:
        html_content = file.read()
    # Return the HTML content directly
    return html_content

@app.route('/audio')
def serve_audio():
    # Serve the MP3 file
    return send_file('attached_assets/ransom in LOW QUALITY.mp3')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)